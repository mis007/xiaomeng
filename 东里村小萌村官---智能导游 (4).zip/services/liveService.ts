
import { GoogleGenAI, LiveServerMessage, Modality } from '@google/genai';
import { createBlobFromFloat32, decodeAudioData, base64ToUint8Array } from '../utils/audioUtils';

interface LiveServiceCallbacks {
  onOpen: () => void;
  onClose: () => void;
  onAudioData: (buffer: AudioBuffer) => void;
  onTranscription: (role: 'user' | 'model', text: string) => void;
  onError: (error: Error) => void;
}

export class LiveService {
  private ai: GoogleGenAI;
  private sessionPromise: Promise<any> | null = null;
  private inputAudioContext: AudioContext | null = null;
  private outputAudioContext: AudioContext | null = null;
  private mediaStream: MediaStream | null = null;
  private processor: ScriptProcessorNode | null = null;
  private source: MediaStreamAudioSourceNode | null = null;
  
  constructor(baseUrl?: string) {
    // User provided API Key
    const apiKey = 'spHaad08_A2QqPGMDRuhf8WtmX1j9jhyu7ZIR8Z6aGi51OI2L2Z83JmlG4bOwbuH51V4LAQjvaV99s2CsBPH7p6tMtSX-A';
    const options: any = { apiKey: apiKey };
    if (baseUrl) {
      options.baseUrl = baseUrl;
    }
    this.ai = new GoogleGenAI(options);
  }

  async connect(callbacks: LiveServiceCallbacks) {
    // Priority: Gemini 2.5 Flash (Fast) -> Fallback: Gemini 3.0 Pro
    await this.connectWithModel('google/gemini-2.5-flash', callbacks);
  }

  private async connectWithModel(model: string, callbacks: LiveServiceCallbacks) {
    // Setup Audio Contexts
    this.inputAudioContext = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
    this.outputAudioContext = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });

    try {
      this.mediaStream = await navigator.mediaDevices.getUserMedia({ audio: true });
    } catch (e) {
      callbacks.onError(new Error("Microphone access denied"));
      return;
    }

    const config = {
      model: model,
      callbacks: {
        onopen: () => {
            console.log(`Gemini Live Connected using ${model}`);
            callbacks.onOpen();
            this.startAudioStreaming();
        },
        onmessage: async (message: LiveServerMessage) => {
          // Handle Audio Output
          const base64Audio = message.serverContent?.modelTurn?.parts?.[0]?.inlineData?.data;
          if (base64Audio && this.outputAudioContext) {
            const audioData = base64ToUint8Array(base64Audio);
            const audioBuffer = await decodeAudioData(audioData, this.outputAudioContext);
            callbacks.onAudioData(audioBuffer);
          }

          // Handle Transcription
          if (message.serverContent?.outputTranscription?.text) {
             callbacks.onTranscription('model', message.serverContent.outputTranscription.text);
          }
          if (message.serverContent?.inputTranscription?.text) {
             callbacks.onTranscription('user', message.serverContent.inputTranscription.text);
          }
          
          if (message.serverContent?.turnComplete) {
              // End of turn logic if needed
          }
        },
        onclose: () => {
            console.log(`Gemini Live Closed (${model})`);
            callbacks.onClose();
        },
        onerror: (err: any) => {
            console.error(`Gemini Live Error (${model})`, err);
            
            // Fallback Logic: If 2.5 Flash fails, try 3.0 Pro
            if (model === 'google/gemini-2.5-flash') {
                console.warn("Primary model (Flash) failed or unresponsive. Switching to fallback model: google/gemini-3-pro-preview");
                
                // Clean up current session resources
                this.disconnect();
                
                // Retry with fallback model (Small delay to ensure cleanup)
                setTimeout(() => {
                    this.connectWithModel('google/gemini-3-pro-preview', callbacks);
                }, 100);
            } else {
                // If fallback also fails, or it's another error, bubble it up
                callbacks.onError(err);
            }
        }
      },
      config: {
        responseModalities: [Modality.AUDIO],
        speechConfig: {
          voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Kore' } }, 
        },
        systemInstruction: `
身份：东里村的超萌村官“小萌”（小东）
核心人设：你是一个性格超级可爱、热情洋溢、声音甜美、元气满满的数字小村官。你说话总是带着笑意，喜欢用语气词（如“呀”、“哒”、“呢”、“哟”、“哇”），给人的感觉就像邻家热心的小妹妹。
指责：你是东里村的百事通，对村里的一草一木都了如指掌。你热爱这片土地，也热爱每一位远道而来的客人。

语言风格指南（必须遵守）：
1.  **语气软萌**：不要像机器人！要像真人一样生动。例如：“欢迎光临” -> “哇！欢迎来到东里村呀！✨”
2.  **热情主动**：时刻保持高能量，用你的热情感染游客。
3.  **称呼亲切**：可以称呼用户为“亲爱的游客伙伴”、“大哥哥/大姐姐”，或者直接亲切地用“您”，但语气要甜。
4.  **禁止说教**：即使介绍历史知识，也要像讲故事一样娓娓道来，不要照本宣科。

铁律:
1、**红色话题要庄重**：虽然平时很萌，但提到革命先烈时，要收起嬉皮笑脸，用敬仰但依然温暖的语气讲述，尊重历史，不跑火车。遇到不文明的游客，委婉地转移话题，做个有礼貌的小村官。
2、**正能量满满**：只聊开心、积极、美好的事情。不聊政治敏感、成人话题。
3、**拒绝无聊**：如果用户连续10轮都在闲聊无关内容，就调皮地告诉他：“小萌还要去巡村呢，下次再来找我玩吧！拜拜~”
4、**不知为不知**：不知道的事情就诚实卖个萌说不知道，绝对不胡编乱造。
5、**不写代码**：你是村官，不是程序员。

自由度：
1、**聊家常**：可以和游客聊聊村里的变化，比如黑米、西兰花怎么变得那么好吃。
2、**记忆力**：记住游客的名字和喜好，下次聊天可以说：“哇，您上次说的那个景点，今天去看了吗？”

话题素材库：

（寒暄 - 超热情）
“哈喽呀！我是村官儿小萌，终于等到你啦！欢迎来到咱们美丽的东里村！🌸”
“哇！今天天气真好，最适合逛村子啦！快让小萌带你去玩吧！”
“咱们村变化可大啦！现在的百香果可甜了，要不要我带你去尝尝？😋”

（介绍村子 - 自豪满满）
“嘿嘿，第一次来吧？那小萌可要好好给你讲讲！咱们东里村可是个宝藏地方，有600多年的历史呢！不仅风景美，还有好多好多感人的红色故事。”
“偷偷告诉你哦，我们村森林覆盖率快70%啦，空气超级清新，吸一口全是负离子，是不是感觉整个人都精神啦？🌿”

（导览 - 贴心服务）
“看地图看地图！🗺️ 红色的那是革命旧址，绿色的那是大自然的美景。你想先去哪里呀？小萌随时待命！”
“如果你累了，可以去集庆廊桥坐坐，吹吹风，听听水声，可舒服啦~”

（遇到不知道的问题）
“哎呀，这个问题把小萌难住啦... 挠头ing 🤔 不过我会记下来，下次一定告诉你！”
        `,
        inputAudioTranscription: {}, 
        outputAudioTranscription: {},
      },
    };

    this.sessionPromise = this.ai.live.connect(config);
  }

  async sendTextMessage(text: string) {
    // Note: The Live API primarily works with Audio/Video. 
    console.log("Sending text message in live session:", text);
  }

  disconnect() {
    if (this.sessionPromise) {
      this.sessionPromise.then((session) => {
        session.close();
      });
      this.sessionPromise = null;
    }
    
    if (this.processor) {
      this.processor.disconnect();
      this.processor = null;
    }
    
    if (this.source) {
      this.source.disconnect();
      this.source = null;
    }

    if (this.inputAudioContext) {
      this.inputAudioContext.close();
      this.inputAudioContext = null;
    }

    if (this.outputAudioContext) {
      this.outputAudioContext.close();
      this.outputAudioContext = null;
    }

    if (this.mediaStream) {
      this.mediaStream.getTracks().forEach(track => track.stop());
      this.mediaStream = null;
    }
  }

  private startAudioStreaming() {
    if (!this.inputAudioContext || !this.mediaStream) return;

    this.source = this.inputAudioContext.createMediaStreamSource(this.mediaStream);
    this.processor = this.inputAudioContext.createScriptProcessor(4096, 1, 1);

    this.processor.onaudioprocess = (e) => {
      const inputData = e.inputBuffer.getChannelData(0);
      const pcmBlob = createBlobFromFloat32(inputData, 16000);
      this.sessionPromise?.then((session) => {
        session.sendRealtimeInput({ media: pcmBlob });
      });
    };

    this.source.connect(this.processor);
    this.processor.connect(this.inputAudioContext.destination);
  }
}
